Team members
Logan Cundiff and Christopher You


•What is working
The entire Chord peer to peer implementation is working with the finger table implemented as well. 

We call each actor with the amount of requests the user inputs. Each actor then searches for a random key for every request. 
The node/actor builds a finger table for the key lookup (as described in the paper). 
We also did the extra credit (seperate file upload) where it deletes nodes in the Chord and transfers the keys to the appropriate node. 


•What is the largest network you managed to deal with? 
10000 nodes

